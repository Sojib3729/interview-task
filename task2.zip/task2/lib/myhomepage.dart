import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key}) : super(key: key);

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      body: SafeArea(
        child: Stack(
          children: [
            Container(
            width: MediaQuery.sizeOf(context).width,
              child: Image(image: AssetImage("images/back.png",),fit: BoxFit.fill,),
            ),

            Positioned(
              top: 50,
                left: 90,
                right: 90,

                
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    SizedBox(height: 20,),
                    Text("Bangaluru",style: TextStyle(color: Colors.white,fontSize: 32),),
                    Text("19",style: TextStyle(color: Colors.white,fontSize: 32),),
                    Text("Mostly clear",style: TextStyle(color: Colors.white,fontSize: 32),),
                    Text("H : 24 L: 18",style: TextStyle(color: Colors.white,fontSize: 32),),
                    Image(image: AssetImage("image/house.png")),
                  ],
                ))
          ],
        ),
      ),
    );
  }
}
