

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:intertest/API/api_services.dart';
import 'package:intertest/model/namaz_time.dart';

class Home extends StatefulWidget {

   Home({Key? key}) : super(key: key);

  @override
  State<Home> createState() => _HomeState();
}



class _HomeState extends State<Home> {
  late Future getSaladTime;
   SaladTimeModel saladTimeModel = SaladTimeModel();

  @override
  void initState() {
    getSaladTime = ApiService().getSalatData(context: context);
    // TODO: implement initState
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      appBar: AppBar(
        title: Text("Home"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(child: Text("Namaz Time",style: TextStyle(fontSize: 20,color: Colors.green),)),
            SizedBox(height: 20,),

            FutureBuilder(future: getSaladTime, builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              } else if (snapshot.hasError) {
                return Text('Error: ${snapshot.error}');
              } else if (snapshot.hasData) {
              saladTimeModel =  snapshot.data!;
              List<Datum> list =  saladTimeModel.data!;
              return SizedBox(
                height: MediaQuery.sizeOf(context).height*0.8,
                child: ListView.builder(
                  itemCount: list.length,
                  itemBuilder:
                    (context, index) {
                    if(list.isNotEmpty)
                      {
                        return Container(
                          decoration: BoxDecoration(

                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Column(
                              children: [
                                TimeItem(Title: "fajr", Time: list[index].timings!.fajr.toString(),),
                                TimeItem(Title: "sunrise", Time: '${list[index].timings!.sunrise}',),
                                TimeItem(Title: "dhuhr", Time: '${list[index].timings!.dhuhr}',),
                                TimeItem(Title: "asr", Time: '${list[index].timings!.asr}',),
                                TimeItem(Title: "sunset", Time: '${list[index].timings!.sunset}',),
                                TimeItem(Title: "maghrib", Time: '${list[index].timings!.maghrib}',),
                                TimeItem(Title: "isha", Time: '${list[index].timings!.isha}',),
                                TimeItem(Title: "Fajr", Time: '${list[index].timings!.imsak}',),
                                TimeItem(Title: "Fajr", Time: '${list[index].timings!.midnight}',),
                                TimeItem(Title: "Fajr", Time: '${list[index].timings!.firstthird}',),
                                TimeItem(Title: "Fajr", Time: '${list[index].timings!.lastthird}',),
                                Row(
                                  mainAxisSize: MainAxisSize.max,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [

                                    Row(
                                      children: [
                                        Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Text("Day: ${list[index].date!.gregorian!.weekday!.en}"),
                                            Text("${list[index].meta!.timezone}"),
                                          ],
                                        ),
                                        SizedBox(width: 30,),
                                        Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Text("Date: ${list[index].date!.readable}"),
                                            Text("Hijri Date: ${list[index].date!.hijri!.date}")
                                          ],
                                        )
                                      ],
                                    ),


                                  ],
                                ),
                                Divider(color: Colors.black54,height: 50,),

                              ],




                            ),
                          ),
                        );
                      }
                    else

                    return Text("NO Data");

                },),
              );
              }
              else {
                return   Text("NO Data");
              }
            },),


          ],
        ),
      ),
    );
  }
}

class TimeItem extends StatelessWidget {
  final String Title;
 final String Time;
  const TimeItem({

    super.key, required this.Title, required this.Time,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [

        Text("$Title : $Time"),


      ],
    );
  }
}
