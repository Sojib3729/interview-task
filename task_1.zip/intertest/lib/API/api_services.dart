import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import 'package:http/http.dart' as http;
import 'package:intertest/model/namaz_time.dart';


class ApiService {

  late SaladTimeModel saladTimeModel;
  Future<SaladTimeModel> getSalatData({
    context,
  }) async {
    String url = "https://api.aladhan.com/v1/calendar/2017/4?latitude=51.508515&longitude=-0.1254872&method=2";

    try{
      final response = await http.get(Uri.parse(url));

      saladTimeModel = saladTimeModelFromJson(response.body);
      if (saladTimeModel.status == "OK") {
        // var areaData = data["area-list"] as List;

        return saladTimeModel;
      }
      else
      {
        ScaffoldMessenger.of(context).showSnackBar( const SnackBar(
            backgroundColor: Colors.red,
            content: Text("Failed")));

        return saladTimeModel;
      }
    }
    catch(e)
    {
      saladTimeModel = SaladTimeModel();
      ScaffoldMessenger.of(context).showSnackBar( const SnackBar(
          backgroundColor: Colors.red,
          content: Text("Erorr Loading Data")));
      return saladTimeModel;
    }

  }



}